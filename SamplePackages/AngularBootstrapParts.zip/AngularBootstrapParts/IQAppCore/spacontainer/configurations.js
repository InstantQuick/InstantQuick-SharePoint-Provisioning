var p=window.iqPart=window.iqPart||{};p.Configurations={
    "default": {
        "Name": "AngularJS and Bootstrap Part",
        "Description": "Generic part using AngularJS 1.4 and Boostrap 3",
        "RootTemplate": "default.html"
    },
    "template": {
        "Name": "",
        "Description": "",
        "RootTemplate": "app.html",
        "Scripts": [
            "app.js"
        ],
        "Styles": [
            "app.css"
        ]
    },
    "509814bf-b130-4b07-b581-e77f600e807b": {
        "SelectedDemo": "timer",
        "Name": "Timer",
        "Description": "Timer configuration example",
        "RootTemplate": "app.html",
        "Scripts": [
            "app.js"
        ],
        "Styles": [
            "app.css"
        ],
        "Modified": "2016-02-04T18:53:24.446Z"
    },
    "2da24c9e-ef9d-45b4-8936-ff6216dc0c31": {
        "Name": "Bootstrap Reference",
        "Description": "Handy bootstrap 3 reference.",
        "RootTemplate": "app.html",
        "Scripts": [
            "app.js"
        ],
        "Styles": [
            "//bootstrapdocs.com/v3.0.0/docs/examples/theme/theme.css",
            "app.css"
        ],
        "Modified": "2016-03-11T16:39:05.597Z"
    }
};